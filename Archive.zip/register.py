"""from flask import Flask, request, render_template,send_from_directory
import os
import sqlite3
import cv2
import face_recognition
import time
import webbrowser
from threading import Timer

app = Flask(__name__)

# Configuration for the upload folder
app.config['UPLOAD_FOLDER'] = 'uploads/'
DB_PATH = 'student_data.db'

# Create uploads directory if it doesn't exist
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])


# Function to capture image from webcam and save it
def capture_image(id):
    # Check if the camera opened successfully
    cap = cv2.VideoCapture(0)  # Open the default camera

    if not cap.isOpened():
        print("Could not open webcam.")
        return None  # Return None if the webcam cannot be opened

    # Give the camera some time to initialize
    time.sleep(2)  # Wait for 2 seconds before capturing the frame

    # Capture multiple frames to allow camera to adjust
    for _ in range(5):  # Capture 5 frames before the final capture
        ret, frame = cap.read()

    # Now capture the final frame
    ret, frame = cap.read()  # Capture the final frame

    # Check if frame was captured successfully
    if ret:
        img_name = os.path.join(app.config['UPLOAD_FOLDER'], f"{id}.jpg")  # Save in 'uploads' folde
        print(f"Saving image to: {img_name}")

        # Save the captured image
        cv2.imwrite(img_name, frame)
        print(f"Image captured and saved as {img_name}")

        cap.release()  # Release the camera
        return img_name  # Return the image path
    else:
        print("Failed to capture image from webcam.")
        cap.release()  # Release the camera if the frame was not captured
        return None


# Function to check if the user is already registered based on face comparison
def is_user_registered_by_face(new_face_encoding):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT photo_path FROM students")
    result = cursor.fetchall()
    conn.close()

    for row in result:
        known_image = face_recognition.load_image_file(row[0])
        known_face_encoding = face_recognition.face_encodings(known_image)[0]
        matches = face_recognition.compare_faces([known_face_encoding], new_face_encoding)
        if True in matches:
            return True
    return False


# Route for the student registration page
@app.route('/')
def index():
    return render_template('register.html')


# Route to handle the registration form submission
@app.route('/register', methods=['POST'])
def register_student():
    id = request.form['id']
    name = request.form['name']

    # Capture the image from webcam
    photo_path = capture_image(id)

    if photo_path:
        # Load the captured image and find its encoding
        new_image = face_recognition.load_image_file(photo_path)
        new_face_encoding = face_recognition.face_encodings(new_image)

        if len(new_face_encoding) > 0:
            new_face_encoding = new_face_encoding[0]


            # Check if the user is already registered by face
            if is_user_registered_by_face(new_face_encoding):
                os.remove(photo_path)  # Remove the duplicate photo
                return "User already registered based on face!", 400
        else:
            os.remove(photo_path)  # Remove the invalid photo
            return "No face detected in the captured image! Please try again.", 400

        # Insert student data into the database
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("INSERT INTO students (id, name, photo_path) VALUES (?, ?, ?)", (id, name, photo_path))
        conn.commit()
        conn.close()

        # Show the image to confirm registration
        # Pass 'id.jpg' as the image_path
        return render_template('show_image.html', image_path=f"{id}.jpg")
    else:
        return "Could not capture photo! Please check your webcam.", 400


# Route to serve images from the uploads directory
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

def open_browser():
    webbrowser.open_new("http://127.0.0.1:5000/")
# Run the Flask application
if __name__ == '__main__':
    # Create the database and table if not exist
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS students 
                 (id TEXT PRIMARY KEY, 
                  name TEXT NOT NULL, 
                  photo_path TEXT NOT NULL)''')
    Timer(1,open_browser).start()
    conn.close()
    app.run()
"""

from flask import Flask, request, render_template, send_from_directory, jsonify, Response
import os
import sqlite3
import cv2
import face_recognition
import time
import webbrowser
from threading import Timer

app = Flask(__name__)

# Configuration for the upload folder
app.config['UPLOAD_FOLDER'] = 'uploads/'
DB_PATH = 'student_data.db'

# Create uploads directory if it doesn't exist
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

# Function to capture image from webcam and save it
def capture_image(id):
    cap = cv2.VideoCapture(0)  # Open the default camera

    if not cap.isOpened():
        print("Could not open webcam.")
        return None

    time.sleep(2)  # Allow the camera to initialize

    # Capture the final frame
    ret, frame = cap.read()
    cap.release()

    if ret:
        img_name = os.path.join(app.config['UPLOAD_FOLDER'], f"{id}.jpg")  # Save the image
        cv2.imwrite(img_name, frame)
        return img_name
    else:
        print("Failed to capture image.")
        return None

# Function to check if the user is already registered based on face comparison
def is_user_registered_by_face(new_face_encoding):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT photo_path FROM students")
    result = cursor.fetchall()
    conn.close()

    for row in result:
        known_image = face_recognition.load_image_file(row[0])
        known_face_encoding = face_recognition.face_encodings(known_image)[0]
        matches = face_recognition.compare_faces([known_face_encoding], new_face_encoding)
        if True in matches:
            return True
    return False

# Route for the student registration page
@app.route('/')
def index():
    return render_template('register.html')

# Route to handle the registration form submission
@app.route('/register', methods=['POST'])
def register_student():
    id = request.form['id']
    name = request.form['name']
    return render_template('camera_window.html', id=id, name=name)

# Camera feed generator for live streaming
def generate_camera_feed():
    cap = cv2.VideoCapture(0)
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Resize frame to fit screen
        frame = cv2.resize(frame, (640, 480))
        _, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    cap.release()

# Route for live camera feed
@app.route('/camera_feed')
def camera_feed():
    return Response(generate_camera_feed(), mimetype='multipart/x-mixed-replace; boundary=frame')

# Route to capture photo after showing camera feed
@app.route('/capture_photo')
def capture_photo():
    id = request.args.get('id')
    photo_path = capture_image(id)
    if photo_path:
        new_image = face_recognition.load_image_file(photo_path)
        new_face_encoding = face_recognition.face_encodings(new_image)

        if len(new_face_encoding) > 0:
            new_face_encoding = new_face_encoding[0]
            if is_user_registered_by_face(new_face_encoding):
                os.remove(photo_path)
                return jsonify({"success": False, "message": "User already registered based on face!"})

        # Save student to database if not already registered
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("INSERT INTO students (id, name, photo_path) VALUES (?, ?, ?)", (id, request.args.get('name'), photo_path))
        conn.commit()
        conn.close()
        return jsonify({"success": True, "message": "Photo captured and saved successfully!"})
    else:
        return jsonify({"success": False, "message": "Failed to capture image."})

# Route to serve images from the uploads directory
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

def open_browser():
    webbrowser.open_new("http://127.0.0.1:5000/")

# Run the Flask application
if __name__ == '__main__':
    # Create the database and table if not exist
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS students 
                 (id TEXT PRIMARY KEY, 
                  name TEXT NOT NULL, 
                  photo_path TEXT NOT NULL)''')
    conn.commit()
    conn.close()

    Timer(1, open_browser).start()
    app.run()
