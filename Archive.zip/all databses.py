import sqlite3

# Establish a connection to the database
conn = sqlite3.connect('student_data.db')

# Create a cursor object using the connection
cursor = conn.cursor()

# Execute a SQL query using the cursor
cursor.execute("SELECT * FROM students")

# Fetch all rows from the executed query
rows = cursor.fetchall()  # This will return all rows as a list of tuples

# Iterate through the rows and print each one
for row in rows:
    print(row)

# Close the cursor and connection when done
cursor.close()
conn.close()


'''import mysql.connector

# Establish a connection
conn = mysql.connector.connect(
    host='localhost',
    user='yourusername',
    password='yourpassword',
    database='yourdatabase'
)

cursor = conn.cursor()

# Query the database
cursor.execute('SELECT * FROM your_table')
for row in cursor.fetchall():
    print(row)

conn.close()'''
