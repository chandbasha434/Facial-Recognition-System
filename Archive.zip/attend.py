"""import cv2
import face_recognition
import os
import pandas as pd
import sqlite3
import numpy as np
from datetime import datetime, time
from flask import Flask, render_template, redirect, url_for, Response
import webbrowser
from threading import Timer, Thread
import time as time_module

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads/'
DB_PATH = 'student_data.db'

# Define the attendance time window
ATTENDANCE_START_TIME = time(9, 0)  # 9:00 AM
ATTENDANCE_END_TIME = time(17, 0)  # 4:45 PM

# Function to load known faces from the database
def load_known_faces():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, photo_path FROM students")
    results = cursor.fetchall()
    conn.close()

    known_encodings, known_names, student_data = [], [], {}
    for student_id, name, photo_path in results:
        if os.path.exists(photo_path):
            image = face_recognition.load_image_file(photo_path)
            face_locations = face_recognition.face_locations(image)
            if face_locations:
                encoding = face_recognition.face_encodings(image, face_locations)[0]
                known_encodings.append(encoding)
                known_names.append(name)
                student_data[name] = student_id
            else:
                print(f"Warning: No face found in the image for {name}. Skipping.")
        else:
            print(f"Warning: File {photo_path} not found. Skipping.")
    return known_encodings, known_names, student_data

# Function to get the current date as Excel filename
def get_excel_file_name():
    return f"{datetime.now().strftime('%Y-%m-%d')}_attendance.xlsx"

# Function to check if the user has already taken attendance
def has_taken_attendance(name, excel_file):
    if not os.path.exists(excel_file):
        return False
    df = pd.read_excel(excel_file)
    return not df[(df['Name'] == name) & (df['Status'] == 'Present')].empty

# Function to mark attendance in Excel file (only within allowed time window)
def mark_attendance_in_excel(student_data, present_students):
    current_time = datetime.now().time()
    if not (ATTENDANCE_START_TIME <= current_time <= ATTENDANCE_END_TIME):
        print("Attendance marking is not allowed outside the specified time window.")
        return

    excel_file = get_excel_file_name()
    date_str, time_str = datetime.now().strftime("%Y-%m-%d"), datetime.now().strftime("%H:%M:%S")

    # Load existing data if file exists, otherwise create a new DataFrame
    if os.path.exists(excel_file):
        df = pd.read_excel(excel_file)
    else:
        df = pd.DataFrame(columns=['ID', 'Name', 'Date', 'Time', 'Status'])

    # Append attendance data for present students
    for name in present_students:
        if not has_taken_attendance(name, excel_file):
            new_row = pd.DataFrame([{
                'ID': student_data[name],
                'Name': name,
                'Date': date_str,
                'Time': time_str,
                'Status': 'Present'
            }])
            df = pd.concat([df, new_row], ignore_index=True)

    # Save updated attendance records to the Excel file
    df.to_excel(excel_file, index=False)

@app.route('/')
def index():
    return render_template('attend.html')

# Function to generate video feed with face detection and name labeling
def generate_camera_feed():
    known_encodings, known_names, student_data = load_known_faces()
    cap = cv2.VideoCapture(0)

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Resize frame for faster face recognition processing
        small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

        # Detect all faces and encodings in the current frame
        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

        present_students = set()

        # Loop through each face detected in the current frame
        for face_encoding, face_location in zip(face_encodings, face_locations):
            matches = face_recognition.compare_faces(known_encodings, face_encoding)
            face_distances = face_recognition.face_distance(known_encodings, face_encoding)
            best_match_index = np.argmin(face_distances)

            # Determine if the face is a match
            if matches[best_match_index]:
                name = known_names[best_match_index]
                present_students.add(name)

                # Mark attendance for recognized face
                mark_attendance_in_excel(student_data, present_students)

                # Scale back up face locations to match the original frame size
                top, right, bottom, left = face_location
                top, right, bottom, left = top * 4, right * 4, bottom * 4, left * 4

                # Draw a box around the face
                cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
                cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 255, 0), cv2.FILLED)
                cv2.putText(frame, name, (left + 6, bottom - 6), cv2.FONT_HERSHEY_DUPLEX, 1.0, (0, 0, 255), 1)
            else:
                # For unrecognized faces, draw a red box
                top, right, bottom, left = face_location
                top, right, bottom, left = top * 4, right * 4, bottom * 4, left * 4
                cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
                cv2.putText(frame, "Unrecognized", (left + 6, bottom - 6), cv2.FONT_HERSHEY_DUPLEX, 1.0,
                            (255, 255, 255), 1)

        # Convert the frame to JPEG format
        ret, jpeg = cv2.imencode('.jpg', frame)
        frame = jpeg.tobytes()
        yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    cap.release()

@app.route('/video_feed')
def video_feed():
    return Response(generate_camera_feed(), mimetype='multipart/x-mixed-replace; boundary=frame')

# Function to mark absentees after 4:45 PM
def mark_absentees():
    known_encodings, known_names, student_data = load_known_faces()
    excel_file = get_excel_file_name()

    if not os.path.exists(excel_file):
        print("No attendance records found for today. Cannot mark absentees.")
        return

    df = pd.read_excel(excel_file)
    present_students = set(df[df['Status'] == 'Present']['Name'])
    absent_students = set(student_data.keys()) - present_students

    date_str, time_str = datetime.now().strftime("%Y-%m-%d"), datetime.now().strftime("%H:%M:%S")
    for name in absent_students:
        new_row = pd.DataFrame([{
            'ID': student_data[name],
            'Name': name,
            'Date': date_str,
            'Time': time_str,
            'Status': 'Absent'
        }])
        df = pd.concat([df, new_row], ignore_index=True)

    # Save updated records to the Excel file
    df.to_excel(excel_file, index=False)
    print(f"Absentees marked for {date_str} after 4:45 PM.")

# Background task to check time every second and mark absentees at 4:45 PM
def absentee_scheduling_task():
    while True:
        current_time = datetime.now().time()
        # Check precisely at 4:45 PM
        if current_time.hour == 17 and current_time.minute == 0 and current_time.second == 0:
            print("Starting absentee marking...")
            mark_absentees()
            time_module.sleep(60)  # Sleep for a minute to avoid re-triggering within the same minute
        time_module.sleep(1)  # Check every second

def open_browser():
    webbrowser.open_new("http://127.0.0.1:5000/")

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    # Start the absentee scheduling task in a background thread
    Thread(target=absentee_scheduling_task, daemon=True).start()

    # Open the browser and run the Flask app
    Timer(1, open_browser).start()
    app.run()"""





"""import cv2
import face_recognition
import os
import pandas as pd
import sqlite3
import numpy as np
from datetime import datetime, time
from flask import Flask, render_template, redirect, url_for, Response
import webbrowser
from threading import Timer, Thread

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads/'
DB_PATH = 'student_data.db'

# Define the attendance time window
ATTENDANCE_START_TIME = time(9, 0)  # 9:00 AM
ATTENDANCE_END_TIME = time(17, 0)  # 5:00 PM

# Function to load known faces from the database
def load_known_faces():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, photo_path FROM students")
    results = cursor.fetchall()
    conn.close()

    known_encodings, known_names, student_data = [], [], {}
    for student_id, name, photo_path in results:
        if os.path.exists(photo_path):
            image = face_recognition.load_image_file(photo_path)
            face_locations = face_recognition.face_locations(image)
            if face_locations:
                encoding = face_recognition.face_encodings(image, face_locations)[0]
                known_encodings.append(encoding)
                known_names.append(name)
                student_data[name] = student_id
            else:
                print(f"Warning: No face found in the image for {name}. Skipping.")
        else:
            print(f"Warning: File {photo_path} not found. Skipping.")
    return known_encodings, known_names, student_data

# Function to get the current date as Excel filename
def get_excel_file_name():
    return f"{datetime.now().strftime('%Y-%m-%d')}_attendance.xlsx"

# Function to create an initial attendance file with all students marked as Absent
def initialize_attendance_file(student_data):
    excel_file = get_excel_file_name()
    date_str, time_str = datetime.now().strftime("%Y-%m-%d"), "09:00:00"  # Default start time

    # Create DataFrame with "Absent" status for each student
    absent_records = pd.DataFrame([{
        'ID': student_id,
        'Name': name,
        'Date': date_str,
        'Time': time_str,
        'Status': 'Absent'
    } for name, student_id in student_data.items()])

    # Save the initial attendance file
    absent_records.to_excel(excel_file, index=False)
    print(f"Attendance file created with all students marked as 'Absent': {excel_file}")

# Function to check if the user has already taken attendance
def has_taken_attendance(name, excel_file):
    if not os.path.exists(excel_file):
        return False
    df = pd.read_excel(excel_file)
    return not df[(df['Name'] == name) & (df['Status'] == 'Present')].empty

# Function to mark attendance in Excel file (only within allowed time window)
def mark_attendance_in_excel(student_data, present_students):
    current_time = datetime.now().time()
    if not (ATTENDANCE_START_TIME <= current_time <= ATTENDANCE_END_TIME):
        print("Attendance marking is not allowed outside the specified time window.")
        return

    excel_file = get_excel_file_name()
    date_str, time_str = datetime.now().strftime("%Y-%m-%d"), datetime.now().strftime("%H:%M:%S")

    # Load existing attendance file
    df = pd.read_excel(excel_file)

    # Update attendance status to 'Present' for students in the current session
    for name in present_students:
        if name in df['Name'].values and not has_taken_attendance(name, excel_file):
            df.loc[df['Name'] == name, ['Date', 'Time', 'Status']] = [date_str, time_str, 'Present']
        else:
            print(f"Attendance for {name} already marked as Present.")

    # Save the updated attendance records to the Excel file
    df.to_excel(excel_file, index=False)

@app.route('/')
def index():
    return render_template('attend.html')

# Function to generate video feed with face detection and name labeling
def generate_camera_feed():
    known_encodings, known_names, student_data = load_known_faces()
    cap = cv2.VideoCapture(0)

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Resize frame for faster face recognition processing
        small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

        # Detect all faces and encodings in the current frame
        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

        present_students = set()

        # Loop through each face detected in the current frame
        for face_encoding, face_location in zip(face_encodings, face_locations):
            matches = face_recognition.compare_faces(known_encodings, face_encoding)
            face_distances = face_recognition.face_distance(known_encodings, face_encoding)
            best_match_index = np.argmin(face_distances)

            # Determine if the face is a match
            if matches[best_match_index]:
                name = known_names[best_match_index]
                present_students.add(name)

                # Mark attendance for recognized face
                mark_attendance_in_excel(student_data, present_students)

                # Scale back up face locations to match the original frame size
                top, right, bottom, left = face_location
                top, right, bottom, left = top * 4, right * 4, bottom * 4, left * 4

                # Draw a box around the face
                cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
                cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 255, 0), cv2.FILLED)
                cv2.putText(frame, name, (left + 6, bottom - 6), cv2.FONT_HERSHEY_DUPLEX, 1.0, (0, 0, 255), 1)
            else:
                # For unrecognized faces, draw a red box
                top, right, bottom, left = face_location
                top, right, bottom, left = top * 4, right * 4, bottom * 4, left * 4
                cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
                cv2.putText(frame, "Unrecognized", (left + 6, bottom - 6), cv2.FONT_HERSHEY_DUPLEX, 1.0,
                            (255, 255, 255), 1)

        # Convert the frame to JPEG format
        ret, jpeg = cv2.imencode('.jpg', frame)
        frame = jpeg.tobytes()
        yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    cap.release()

@app.route('/video_feed')
def video_feed():
    return Response(generate_camera_feed(), mimetype='multipart/x-mixed-replace; boundary=frame')

def open_browser():
    webbrowser.open_new("http://127.0.0.1:5000/")

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    # Load known faces and mark all students as absent initially
    known_encodings, known_names, student_data = load_known_faces()
    initialize_attendance_file(student_data)

    # Open the browser and run the Flask app
    Timer(1, open_browser).start()
    app.run()"""






########MAIN






import cv2
import face_recognition
import os
import pandas as pd
import sqlite3
import numpy as np
from datetime import datetime, time
from flask import Flask, render_template, redirect, url_for, Response
import webbrowser
from threading import Timer
import subprocess

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads/'
DB_PATH = 'student_data.db'

# Define the attendance time window
ATTENDANCE_START_TIME = time(9, 0)  # 9:00 AM
ATTENDANCE_END_TIME = time(17, 0)  # 5:00 PM

# Function to load known faces from the database
def load_known_faces():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, photo_path FROM students")
    results = cursor.fetchall()
    conn.close()

    known_encodings, known_names, student_data = [], [], {}
    for student_id, name, photo_path in results:
        if os.path.exists(photo_path):
            image = face_recognition.load_image_file(photo_path)
            face_locations = face_recognition.face_locations(image)
            if face_locations:
                encoding = face_recognition.face_encodings(image, face_locations)[0]
                known_encodings.append(encoding)
                known_names.append(name)
                student_data[name] = student_id
            else:
                print(f"Warning: No face found in the image for {name}. Skipping.")
        else:
            print(f"Warning: File {photo_path} not found. Skipping.")
    return known_encodings, known_names, student_data

# Function to get the current date as Excel filename
def get_excel_file_name():
    return f"{datetime.now().strftime('%Y-%m-%d')}_attendance.xlsx"

# Function to create an initial attendance file with all students marked as Absent
def initialize_attendance_file(student_data):
    excel_file = get_excel_file_name()
    date_str, time_str = datetime.now().strftime("%Y-%m-%d"), "09:00:00"  # Default start time

    # Create DataFrame with "Absent" status for each student
    absent_records = pd.DataFrame([{
        'ID': student_id,
        'Name': name,
        'Date': date_str,
        'Time': time_str,
        'Status': 'Absent'
    } for name, student_id in student_data.items()])

    # Save the initial attendance file
    absent_records.to_excel(excel_file, index=False)
    print(f"Attendance file created with all students marked as 'Absent': {excel_file}")

    # Automatically open the Excel file
    subprocess.Popen(['open', excel_file])  # For MacOS, use 'open'. For Windows, replace with 'start'

# Function to check if the user has already taken attendance
def has_taken_attendance(name, excel_file):
    if not os.path.exists(excel_file):
        return False
    df = pd.read_excel(excel_file)
    return not df[(df['Name'] == name) & (df['Status'] == 'Present')].empty

# Function to mark attendance in Excel file (only within allowed time window)
def mark_attendance_in_excel(student_data, present_students):
    current_time = datetime.now().time()
    if not (ATTENDANCE_START_TIME <= current_time <= ATTENDANCE_END_TIME):
        print("Attendance marking is not allowed outside the specified time window.")
        return

    excel_file = get_excel_file_name()
    date_str, time_str = datetime.now().strftime("%Y-%m-%d"), datetime.now().strftime("%H:%M:%S")

    # Load existing attendance file
    df = pd.read_excel(excel_file)

    # Update attendance status to 'Present' for students in the current session
    for name in present_students:
        if name in df['Name'].values and not has_taken_attendance(name, excel_file):
            df.loc[df['Name'] == name, ['Date', 'Time', 'Status']] = [date_str, time_str, 'Present']
        else:
            print(f"Attendance for {name} already marked as Present.")

    # Save the updated attendance records to the Excel file
    df.to_excel(excel_file, index=False)

@app.route('/')
def index():
    return render_template('attend.html')

# Function to generate video feed with face detection and name labeling
def generate_camera_feed():
    known_encodings, known_names, student_data = load_known_faces()
    cap = cv2.VideoCapture(0)

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Resize frame for faster face recognition processing
        small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

        # Detect all faces and encodings in the current frame
        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

        present_students = set()

        # Loop through each face detected in the current frame
        for face_encoding, face_location in zip(face_encodings, face_locations):
            matches = face_recognition.compare_faces(known_encodings, face_encoding)
            face_distances = face_recognition.face_distance(known_encodings, face_encoding)
            best_match_index = np.argmin(face_distances)

            # Determine if the face is a match
            if matches[best_match_index]:
                name = known_names[best_match_index]
                present_students.add(name)

                # Mark attendance for recognized face
                mark_attendance_in_excel(student_data, present_students)

                # Scale back up face locations to match the original frame size
                top, right, bottom, left = face_location
                top, right, bottom, left = top * 4, right * 4, bottom * 4, left * 4

                # Draw a box around the face
                cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
                cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 255, 0), cv2.FILLED)
                cv2.putText(frame, name, (left + 6, bottom - 6), cv2.FONT_HERSHEY_DUPLEX, 1.0, (0, 0, 255), 1)
            else:
                # For unrecognized faces, draw a red box
                top, right, bottom, left = face_location
                top, right, bottom, left = top * 4, right * 4, bottom * 4, left * 4
                cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
                cv2.putText(frame, "Unrecognized", (left + 6, bottom - 6), cv2.FONT_HERSHEY_DUPLEX, 1.0,
                            (255, 255, 255), 1)

        # Convert the frame to JPEG format
        ret, jpeg = cv2.imencode('.jpg', frame)
        frame = jpeg.tobytes()
        yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    cap.release()

@app.route('/video_feed')
def video_feed():
    return Response(generate_camera_feed(), mimetype='multipart/x-mixed-replace; boundary=frame')

def open_browser():
    webbrowser.open_new("http://127.0.0.1:5000/")

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    # Load known faces and mark all students as absent initially
    known_encodings, known_names, student_data = load_known_faces()
    initialize_attendance_file(student_data)

    # Open the browser and run the Flask app
    Timer(1, open_browser).start()
    app.run()







